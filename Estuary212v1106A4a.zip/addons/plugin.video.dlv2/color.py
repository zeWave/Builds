def color(_color: str, text: str, bold: bool=True):
    if bold is True:
        return f'[B][COLOR {_color}]{text}[/COLOR][/B]'
    return f'[COLOR {_color}]{text}[/COLOR]'
    
def snow(text: str):
    return color('snow', text)

def gold(text: str):
    return color('gold', text)

def deepskyblue(text: str):
    return color('deepskyblue', text)

def cyan(text: str):
    return color('cyan', text)

def limegreen(text: str):
    return color('limegreen', text)

def orange(text: str):
    return color('orange', text)

def steelblue(text: str):
    return color('steelblue', text)

def dodgerblue(text: str):
    return color('dodgerblue', text)

def springgreen(text: str):
    return color('springgreen', text)

def red(text: str):
    return color('red', text)

def star_wrap(text: str):
    return f'{gold("******* ")}{text}{gold(" *******")}'
    